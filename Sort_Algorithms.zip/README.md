# icc2t1
lugar onde o professor pode baixar o trabalho

MD5: 2749ad4dd56bb55501a0fa2820ca2388 <<--- se refere ao arquivo tar.xz e não a este repositório

Integrantes:
1- Bruno Maximo (10442235)
2- Débora Ngan (11218650)
3- Pedro Fernando Christofoletti Dos Santos (11218560)
4- Heitor Camilo (11297785)
5- Henrique Franzin (11218643)
