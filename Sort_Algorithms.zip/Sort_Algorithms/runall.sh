cc original.c -lm
#todos os bubbles sem sentinela
#todos os randomicos
#./a.out -b -r -k 2 
#./a.out -b -r -k 3
#./a.out -b -r -k 4
#./a.out -b -r -k 5
./a.out -b -r -k 6
#todos os crescentes
#./a.out -b -a -k 2
#./a.out -b -a -k 3
#./a.out -b -a -k 4
#./a.out -b -a -k 5
./a.out -b -a -k 6
##todos os decrescentes
#./a.out -b -d -k 2
#./a.out -b -d -k 3
#./a.out -b -d -k 4
#./a.out -b -d -k 5
./a.out -b -d -k 6
##todos os 10% ordenados
#./a.out -b -p -k 2
#./a.out -b -p -k 3
#./a.out -b -p -k 4
#./a.out -b -p -k 5
./a.out -b -p -k 6
#
##todos os bubbles com sentinela
##todos os randomicos
#./a.out -g -r -k 2 
#./a.out -g -r -k 3
#./a.out -g -r -k 4
#./a.out -g -r -k 5
./a.out -g -r -k 6
##todos os crescentes
#./a.out -g -a -k 2
#./a.out -g -a -k 3
#./a.out -g -a -k 4
#./a.out -g -a -k 5
./a.out -g -a -k 6
#todos os decrescentes
#./a.out -g -d -k 2
#./a.out -g -d -k 3
#./a.out -g -d -k 4
#./a.out -g -d -k 5
./a.out -g -d -k 6
#todos os 10% ordenados
#./a.out -g -p -k 2
#./a.out -g -p -k 3
#./a.out -g -p -k 4
#./a.out -g -p -k 5
./a.out -g -p -k 6

#todos os selections
#todos os randomicos
#./a.out -s -r -k 2 
#./a.out -s -r -k 3
#./a.out -s -r -k 4
#./a.out -s -r -k 5
#./a.out -s -r -k 6
#todos os crescentes
#./a.out -s -a -k 2
#./a.out -s -a -k 3
#./a.out -s -a -k 4
#./a.out -s -a -k 5
#./a.out -s -a -k 6
##todos os decrescentes
#./a.out -s -d -k 2
#./a.out -s -d -k 3
#./a.out -s -d -k 4
#./a.out -s -d -k 5
#./a.out -s -d -k 6
##todos os 10% ordenados
#./a.out -s -p -k 2
#./a.out -s -p -k 3
#./a.out -s -p -k 4
#./a.out -s -p -k 5
#./a.out -s -p -k 6
#
##todos os insertions
##todos os randomicos
#./a.out -i -r -k 2 
#./a.out -i -r -k 3
#./a.out -i -r -k 4
#./a.out -i -r -k 5
#./a.out -i -r -k 6
##todos os crescentes
#./a.out -i -a -k 2
#./a.out -i -a -k 3
#./a.out -i -a -k 4
#./a.out -i -a -k 5
#./a.out -i -a -k 6
##todos os decrescentes
#./a.out -i -d -k 2
#./a.out -i -d -k 3
#./a.out -i -d -k 4
#./a.out -i -d -k 5
#./a.out -i -d -k 6
##todos os 10% ordenados
#./a.out -i -p -k 2
#./a.out -i -p -k 3
#./a.out -i -p -k 4
#./a.out -i -p -k 5
#./a.out -i -p -k 6
#
##todos os merge
##todos os randomicos
#./a.out -m -r -k 2 
#./a.out -m -r -k 3
#./a.out -m -r -k 4
#./a.out -m -r -k 5
##./a.out -m -r -k 6
##todos os crescentes
#./a.out -m -a -k 2
#./a.out -m -a -k 3
#./a.out -m -a -k 4
#./a.out -m -a -k 5
##./a.out -m -a -k 6
##todos os decrescentes
#./a.out -m -d -k 2
#./a.out -m -d -k 3
#./a.out -m -d -k 4
#./a.out -m -d -k 5
##./a.out -m -d -k 6
##todos os 10% ordenados
#./a.out -m -p -k 2
#./a.out -m -p -k 3
#./a.out -m -p -k 4
#./a.out -m -p -k 5
##./a.out -m -p -k 6
#
##todos os heap
##todos os randomicos
#./a.out -h -r -k 2 
#./a.out -h -r -k 3
#./a.out -h -r -k 4
#./a.out -h -r -k 5
#./a.out -h -r -k 6
##todos os crescentes
#./a.out -h -a -k 2
#./a.out -h -a -k 3
#./a.out -h -a -k 4
#./a.out -h -a -k 5
#./a.out -h -a -k 6
##todos os decrescentes
#./a.out -h -d -k 2
#./a.out -h -d -k 3
#./a.out -h -d -k 4
#./a.out -h -d -k 5
#./a.out -h -d -k 6
##todos os 10% ordenados
#./a.out -h -p -k 2
#./a.out -h -p -k 3
#./a.out -h -p -k 4
#./a.out -h -p -k 5
#./a.out -h -p -k 6
#
##todos os quick
##todos os randomicos
#./a.out -q -r -k 2 
#./a.out -q -r -k 3
#./a.out -q -r -k 4
#./a.out -q -r -k 5
##./a.out -q -r -k 6
##todos os crescentes
#./a.out -q -a -k 2
#./a.out -q -a -k 3
#./a.out -q -a -k 4
#./a.out -q -a -k 5
##./a.out -q -a -k 6
##todos os decrescentes
#./a.out -q -d -k 2
#./a.out -q -d -k 3
#./a.out -q -d -k 4
#./a.out -q -d -k 5
##./a.out -q -d -k 6
##todos os 10% ordenados
#./a.out -q -p -k 2
#./a.out -q -p -k 3
#./a.out -q -p -k 4
#./a.out -q -p -k 5
##./a.out -q -p -k 6
#
##todos os shell
##todos os randomicos
#./a.out -z -r -k 2 
#./a.out -z -r -k 3
#./a.out -z -r -k 4
#./a.out -z -r -k 5
##./a.out -z -r -k 6
##todos os crescentes
#./a.out -z -a -k 2
#./a.out -z -a -k 3
#./a.out -z -a -k 4
#./a.out -z -a -k 5
##./a.out -z -a -k 6
##todos os decrescentes
#./a.out -z -d -k 2
#./a.out -z -d -k 3
#./a.out -z -d -k 4
#./a.out -z -d -k 5
##./a.out -z -d -k 6
##todos os 10% ordenados
#./a.out -z -p -k 2
#./a.out -z -p -k 3
#./a.out -z -p -k 4
#./a.out -z -p -k 5
##./a.out -z -p -k 6
#